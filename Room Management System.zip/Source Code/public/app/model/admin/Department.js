Ext.define('App.model.admin.Department', {
    extend: 'Ext.data.Model',
    fields: [
        "id",
        "name",
        "description",
        "created_at",
        "updated_at",
    ]

});
