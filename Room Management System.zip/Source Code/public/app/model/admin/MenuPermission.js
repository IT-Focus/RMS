Ext.define('App.model.admin.MenuPermission', {
    extend: 'Ext.data.Model',
    fields:"id menu_id role_id menu_name _destroy checked".split(" ")

});
