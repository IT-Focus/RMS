Ext.define('App.model.admin.NextCode', {
    extend: 'Ext.data.Model',
    fields: [
        'id',
        'module',
        'cit',
        'cet',
        'prefix',
        'suffix',
        'length',
        'created_at',
        'updated_at',
    ]

});
