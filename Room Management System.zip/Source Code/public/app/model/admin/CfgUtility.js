Ext.define('App.model.admin.CfgUtility', {
    extend: 'Ext.data.Model',
    fields: [
        "id",
        "util_name",
        "util_int",
        "util_string",
        "util_boolean",
        "util_date",
        "description"
    ]
});


