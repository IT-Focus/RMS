Ext.define('App.model.setup.RoomMaster', {
    extend: 'Ext.data.Model',
    fields: [
        "id",
        "room_no",
        "category_id",
        "floor_id",
        "status_id",
        "extn_no",
    	
    	"category_name",
    	"floor_name",
    	"status_name"



    ]

});
