Ext.define('App.model.setup.Currency', {
    extend: 'Ext.data.Model',
    fields: [
       
       	'id',
       	'currency_name',
       	'currencysyb',
       	'rate',
       	'exchange_rate',
       	'seq_num',
       	'created_at',
       	'updated_at',
    ]

});
