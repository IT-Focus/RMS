Ext.define('App.model.setup.City', {
    extend: 'Ext.data.Model',
    fields: [
        "id",
        "city",
        "created_at",
        "updated_at",
    ]

});
