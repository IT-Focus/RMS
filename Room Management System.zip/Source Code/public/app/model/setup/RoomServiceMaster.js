Ext.define('App.model.setup.RoomServiceMaster', {
    extend: 'Ext.data.Model',
    fields: [
    
        "id",
        "code",
        "service_name",
        "abbr",
        "charge_amount",
        "is_include_tax",
        "tax",
        "created_by",
        "edited_by",
        "created_at",
        "updated_at",



    ]

});
