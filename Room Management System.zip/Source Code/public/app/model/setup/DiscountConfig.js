Ext.define('App.model.setup.DiscountConfig', {
    extend: 'Ext.data.Model',
    fields: [
        'id',
        'code',
        'remark',
        'created_by',
        'edited_by',
        'deleted_by',
        'is_delete',
        'created_at',
        'updated_at',
    ]

});
