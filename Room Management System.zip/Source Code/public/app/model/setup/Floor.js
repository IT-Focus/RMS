Ext.define('App.model.setup.Floor', {
    extend: 'Ext.data.Model',
    fields: [
        "id",
        "code",
        "name",
        "description",
        "created_at",
        "updated_at",
    ]

});
