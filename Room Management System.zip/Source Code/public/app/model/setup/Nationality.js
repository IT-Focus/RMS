Ext.define('App.model.setup.Nationality', {
    extend: 'Ext.data.Model',
    fields: [
      
      	'id',
      	'iso',
      	'name',
      	'nicename',
      	'iso3',
      	'numcode',
      	'phonecode',
      	'created_at',
      	'updated_at',
    ]

});
