Ext.define('App.model.setup.Workshift', {
    extend: 'Ext.data.Model',
    fields: [
       
       	'id',
       	'abbr',
       	'name',
       	'start_time',
       	'end_time',
       	'description',
       	'created_at',
       	'updated_at',
    ]

});
