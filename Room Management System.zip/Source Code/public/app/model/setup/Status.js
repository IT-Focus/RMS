Ext.define('App.model.setup.Status', {
    extend: 'Ext.data.Model',
    fields: [
       
       	"id",
       	"status_type",
       	"name",
       	"seq_num",
       	"description",
       	"created_at",
       	"updated_at",
    ]

});
