
Ext.define('App.controller.admin.Auditrail', {
	extend: 'Ext.app.Controller',
	views:[
		'admin.auditrail.Index',

	],	
	stores:[
		'admin.Auditrail'
	],
	init: function() {
		
	    this.control({
	    	
	    });
	},





})