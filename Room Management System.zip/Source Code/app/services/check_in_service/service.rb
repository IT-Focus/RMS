class CheckInService::Service
	def change_room_status room_master_id
		roomMaster = RoomMaster.find room_master_id
		roomMaster.update_attributes(status_id:3)
		roomMaster.save

		return true
	end

	def insert_into_auditrail user_id
		auditrail = Auditrail.new(
			module_name:'Check In',
			action:'Create Check In',
			description:'Room Check In',
			created_by:user_id
		)
		auditrail.save
	end

	
end