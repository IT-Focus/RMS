module NextCodeHelper
end
