module RoomMasterHelper
end
