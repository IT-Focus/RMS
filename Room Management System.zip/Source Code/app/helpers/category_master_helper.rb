module CategoryMasterHelper
end
