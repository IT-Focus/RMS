module DepartmentHelper
end
