module CfgCompanyHelper
end
