module CheckInHelper
end
