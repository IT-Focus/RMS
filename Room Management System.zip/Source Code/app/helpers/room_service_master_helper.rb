module RoomServiceMasterHelper
end
