module LicenseHelper
end
