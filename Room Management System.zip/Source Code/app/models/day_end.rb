class DayEnd < ActiveRecord::Base
end
