class CfgCompany < ActiveRecord::Base
	self.table_name = "cfg_companies"
end
