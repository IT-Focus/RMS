class Auditrail < ActiveRecord::Base
end
