class CfgAuditrailType < ActiveRecord::Base
end
