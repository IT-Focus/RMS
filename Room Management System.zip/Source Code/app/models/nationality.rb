class Nationality < ActiveRecord::Base
end
