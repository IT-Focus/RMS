class RoomTransaction < ActiveRecord::Base
end
