class DefaultColor < ActiveRecord::Base
end
