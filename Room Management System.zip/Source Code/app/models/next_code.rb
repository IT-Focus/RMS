class NextCode < ActiveRecord::Base
end
