class RoomServiceMaster < ActiveRecord::Base
end
