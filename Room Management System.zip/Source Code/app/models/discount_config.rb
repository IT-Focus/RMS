class DiscountConfig < ActiveRecord::Base
	self.table_name = "discount_config"
end
