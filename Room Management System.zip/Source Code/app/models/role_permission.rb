class RolePermission < ActiveRecord::Base
end
