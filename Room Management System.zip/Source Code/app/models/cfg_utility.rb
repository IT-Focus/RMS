class CfgUtility < ActiveRecord::Base
end
