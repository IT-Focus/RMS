class Currency < ActiveRecord::Base
end
