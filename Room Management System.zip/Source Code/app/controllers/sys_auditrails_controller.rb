class SysAuditrailsController < ApplicationController
end
