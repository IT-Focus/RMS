class CfgUtilityController < ApplicationController
end
