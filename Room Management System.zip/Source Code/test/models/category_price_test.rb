require 'test_helper'

class CategoryPriceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
