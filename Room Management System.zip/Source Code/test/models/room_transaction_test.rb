require 'test_helper'

class RoomTransactionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
