require 'test_helper'

class DiscountConfigTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
