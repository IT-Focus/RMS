require 'test_helper'

class CfgUtilityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
