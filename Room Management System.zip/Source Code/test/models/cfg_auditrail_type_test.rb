require 'test_helper'

class CfgAuditrailTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
