require 'test_helper'

class RelMenuRoleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
