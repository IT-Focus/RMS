require 'test_helper'

class CheckInDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
