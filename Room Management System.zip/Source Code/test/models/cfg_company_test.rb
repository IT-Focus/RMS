require 'test_helper'

class CfgCompanyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
