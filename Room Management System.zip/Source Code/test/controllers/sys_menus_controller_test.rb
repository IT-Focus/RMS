require 'test_helper'

class SysMenusControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
