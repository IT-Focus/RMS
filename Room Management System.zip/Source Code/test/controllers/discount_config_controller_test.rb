require 'test_helper'

class DiscountConfigControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
