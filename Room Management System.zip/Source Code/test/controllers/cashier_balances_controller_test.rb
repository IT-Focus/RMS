require 'test_helper'

class CashierBalancesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
