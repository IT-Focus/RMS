require 'test_helper'

class StatusControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
