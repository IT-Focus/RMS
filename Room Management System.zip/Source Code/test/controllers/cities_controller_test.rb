require 'test_helper'

class CitiesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
