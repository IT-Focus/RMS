require 'test_helper'

class CfgUtilityControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
