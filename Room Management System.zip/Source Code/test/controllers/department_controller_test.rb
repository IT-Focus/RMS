require 'test_helper'

class DepartmentControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
